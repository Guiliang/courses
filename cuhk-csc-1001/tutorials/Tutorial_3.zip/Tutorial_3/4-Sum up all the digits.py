##Prompt up the indicator for user to enter
number=eval(input("Enter a number between 0 and 1000:"))

##Use the variable to do the operation
sumup=0
sumup+=number%10 #2, sumup = 0+2 = 2
number//=10 #number==93
sumup+=number%10 #3, sumup = 2+3 = 5
number//=10 #number==9
sumup+=number%10 #9, sumup= 5+9 =14

##Display the result
print("Sum up all the digits as:",sumup)
