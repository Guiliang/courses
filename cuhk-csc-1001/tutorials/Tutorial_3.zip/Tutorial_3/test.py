

a = eval(input("enter:"))
print(type(a))
print('here:', a)