package com.example.lecture4_javafx_example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class JavaFXLoginRegister extends Application {

    private Stage primaryStage;
    private Scene loginScene, registerScene;

    // Simulated database (HashMap to store user credentials)
    private Map<String, String> users = new HashMap<>();

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        // Initialize Login and Register Scenes
        loginScene = createLoginScene();
        registerScene = createRegisterScene();

        primaryStage.setScene(loginScene);
        primaryStage.setTitle("JavaFX Login & Register");
        primaryStage.show();
    }

    // Create Login Scene
    private Scene createLoginScene() {
        Label titleLabel = new Label("Login");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        Button loginButton = new Button("Login");
        Label messageLabel = new Label();

        Button switchToRegister = new Button("Create an Account");

        // Login Button Action
        loginButton.setOnAction(e -> {
            String username = userField.getText();
            String password = passField.getText();

            if (users.containsKey(username) && users.get(username).equals(password)) {
                messageLabel.setText("Login successful!");
                messageLabel.setStyle("-fx-text-fill: green;");
            } else {
                messageLabel.setText("Invalid credentials!");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        });

        // Switch to Register Scene
        switchToRegister.setOnAction(e -> primaryStage.setScene(registerScene));

        VBox layout = new VBox(10, titleLabel, userLabel, userField, passLabel, passField, loginButton, messageLabel, switchToRegister);
        layout.setStyle("-fx-padding: 20px; -fx-alignment: center;");

        return new Scene(layout, 300, 350);
    }

    // Create Register Scene
    private Scene createRegisterScene() {
        Label titleLabel = new Label("Register");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label userLabel = new Label("New Username:");
        TextField userField = new TextField();

        Label passLabel = new Label("New Password:");
        PasswordField passField = new PasswordField();

        Button registerButton = new Button("Register");
        Label messageLabel = new Label();

        Button backToLogin = new Button("Back to Login");

        // Register Button Action
        registerButton.setOnAction(e -> {
            String username = userField.getText();
            String password = passField.getText();

            if (users.containsKey(username)) {
                messageLabel.setText("Username already taken!");
                messageLabel.setStyle("-fx-text-fill: red;");
            } else if (username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please fill all fields!");
                messageLabel.setStyle("-fx-text-fill: red;");
            } else {
                users.put(username, password);
                messageLabel.setText("Registration successful!");
                messageLabel.setStyle("-fx-text-fill: green;");
            }
        });

        // Switch back to Login Scene
        backToLogin.setOnAction(e -> primaryStage.setScene(loginScene));

        VBox layout = new VBox(10, titleLabel, userLabel, userField, passLabel, passField, registerButton, messageLabel, backToLogin);
        layout.setStyle("-fx-padding: 20px; -fx-alignment: center;");

        return new Scene(layout, 300, 350);
    }

    public static void main(String[] args) {
        launch(args);
    }
}