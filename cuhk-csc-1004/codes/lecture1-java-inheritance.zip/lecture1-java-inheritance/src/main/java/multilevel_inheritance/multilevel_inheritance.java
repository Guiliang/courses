package multilevel_inheritance;

class Animals{
    void eat(){System.out.println("eating...");}
}
class Dogs extends Animals{
    void bark(){System.out.println("barking...");}

    void eat(){System.out.println("123...");}
}
class BabyDog extends Dogs{
    void weep(){System.out.println("weeping...");}

    void eat(){System.out.println("456...");}
}
class TestInheritance2{
    public static void main(String args[]){
        Animals d=new BabyDog();
//        d.weep();
//        d.bark();
        d.eat();
    }}