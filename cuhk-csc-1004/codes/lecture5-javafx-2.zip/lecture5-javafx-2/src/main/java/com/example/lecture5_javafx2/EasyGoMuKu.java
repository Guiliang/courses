package com.example.lecture5_javafx2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;

public class EasyGoMuKu extends Application {

    private static final int SIZE = 15; // 15x15 Go-Moku board
    private static final int CELL_SIZE = 30; // Cell size in pixels
    private boolean isBlackTurn = true; // Track whose turn it is

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                Pane cell = new Pane();
                cell.setPrefSize(CELL_SIZE, CELL_SIZE);
                cell.setStyle("-fx-border-color: black"); // Set border color for cell
                final int row = i;
                final int col = j;

                // Add a mouse click listener to the cell
                cell.setOnMouseClicked(e -> placePiece(cell, row, col));

                gridPane.add(cell, j, i);
            }
        }

        Scene scene = new Scene(gridPane);
        primaryStage.setTitle("Go-Moku Game Board");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void placePiece(Pane cell, int row, int col) {
        if (!cell.getChildren().isEmpty()) {
            // Cell is already occupied
            return;
        }

        double ellipseRadius = CELL_SIZE * 0.4;
        Ellipse ellipse = new Ellipse(ellipseRadius, ellipseRadius);
        ellipse.setCenterX(CELL_SIZE / 2);
        ellipse.setCenterY(CELL_SIZE / 2);

        if (isBlackTurn) {
            ellipse.setFill(Color.BLACK);
        } else {
            ellipse.setFill(Color.GRAY);
        }

        // Alternate turns
        isBlackTurn = !isBlackTurn;

        // Add the piece to the cell
        cell.getChildren().add(ellipse);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
