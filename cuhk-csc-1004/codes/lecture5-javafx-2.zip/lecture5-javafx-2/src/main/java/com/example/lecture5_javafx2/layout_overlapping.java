package com.example.lecture5_javafx2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class layout_overlapping extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create the outer GridPane
        GridPane outerGridPane = new GridPane();
        outerGridPane.setPadding(new Insets(10));
        outerGridPane.setHgap(10);
        outerGridPane.setVgap(10);

        // Add some content to the outer GridPane
        outerGridPane.add(new Button("Outer 1"), 0, 0);
        outerGridPane.add(new Button("Outer 2"), 1, 0);

        // Create the inner GridPane
        GridPane innerGridPane = new GridPane();
        innerGridPane.setPadding(new Insets(5));
        innerGridPane.setHgap(5);
        innerGridPane.setVgap(5);

        // Add some content to the inner GridPane
        innerGridPane.add(new Button("Inner A"), 0, 0);
        innerGridPane.add(new Button("Inner B"), 1, 0);
        innerGridPane.add(new Button("Inner C"), 0, 1);
        innerGridPane.add(new Button("Inner D"), 1, 1);

        // Add the inner GridPane to the outer GridPane at position (0, 1)
        outerGridPane.add(innerGridPane, 0, 1);

        // Create the Scene with the outer GridPane as the root
        Scene scene = new Scene(outerGridPane, 300, 200);

        // Set the stage with the scene and show it
        primaryStage.setTitle("Nested GridPane Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}

