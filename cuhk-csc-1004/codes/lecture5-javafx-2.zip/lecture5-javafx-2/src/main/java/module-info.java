module com.example.lecture5_javafx2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lecture5_javafx2 to javafx.fxml;
    exports com.example.lecture5_javafx2;
}