module com.example.lecture6javafx4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lecture6_javafx4 to javafx.fxml;
    exports com.example.lecture6_javafx4;
}