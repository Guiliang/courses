module com.example.lecture6_javafx3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lecture6_javafx3 to javafx.fxml;
    exports com.example.lecture6_javafx3;
}