from tkinter import *
root = Tk()
canvas = Canvas(root, bg="black", height=250, width=300)
cell_size = 20
snake = [(100, 100), (80, 100), (60, 100), (40, 100), (40, 80)]
food = (40, 40)
for x, y in snake:
    canvas.create_rectangle(x, y, x + cell_size, y + cell_size, fill='green')
canvas.create_rectangle(food[0], food[1], food[0] + cell_size, food[1] + cell_size, fill='red')
canvas.pack()
mainloop()
