from tkinter import *

root = Tk()
canvas = Canvas(root, bg="black", height=250, width=300)
canvas.pack()

cell_size = 20
snake = [(100, 100), (80, 100), (60, 100), (40, 100), (40, 80)]
food = (40, 40)


def update_ui():
    global snake
    if snake[0][0] + cell_size > 300:  # snake moves out of the canvas
        canvas.destroy()
        root.destroy()
        return
    snake = [(snake[0][0] + cell_size, snake[0][1])] + snake[:-1]
    canvas.delete('all')
    for x, y in snake:
        canvas.create_rectangle(x, y, x + cell_size, y + cell_size, fill='green')
    canvas.create_rectangle(food[0], food[1], food[0] + cell_size, food[1] + cell_size, fill='red')
    root.after(500, update_ui)


root.after(500, update_ui)

mainloop()
