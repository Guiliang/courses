module com.example.lecture4_javafx_example {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lecture4_javafx_example to javafx.fxml;
    exports com.example.lecture4_javafx_example;
}