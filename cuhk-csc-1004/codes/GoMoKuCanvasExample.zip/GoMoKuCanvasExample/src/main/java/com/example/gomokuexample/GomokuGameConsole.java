package com.example.gomokuexample;

public class GomokuGameConsole {
    public static void main(String[] args) {
        GomokuGame game = new GomokuGame(18);
        game.play();
    }
}