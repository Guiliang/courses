import java.io.*;
import java.net.*;


public class BuggySocketProgram {

    // Server part
    public static void startServer() {
        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Server started. Waiting for client...");

            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream())
            );
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream());

            String message;
            while ((message = in.readLine()) != null) {
                System.out.println("Client says: " + message);
                out.println("You said: " + message.toUpperCase());
                // BUG: forgot to flush the output
            }

            in.close();
            out.close();
            clientSocket.close();
            // BUG: forgot to close the server socket

        } catch (IOException e) {
            System.out.println("Server Error: " + e.getMessage());
        }
    }

    // Client part
    public static void startClient() {
        try {
            Socket socket = new Socket("localhost", 5000);
            System.out.println("Connected to server!");

            BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream())
            );
            PrintWriter out = new PrintWriter(socket.getOutputStream());

            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            String input;
            while (true) {
                System.out.print("Enter message: ");
                input = userInput.readLine();
                out.println(input);
                // BUG: forgot to flush the output
                String response = in.readLine();
                System.out.println("Server replied: " + response);
                if (input.equalsIgnoreCase("exit"))
                    break;
            }

            in.close();
            out.close();
            socket.close();
            userInput.close();

        } catch (IOException e) {
            System.out.println("Client Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("server")) {
            startServer();
        } else {
            startClient();
        }
    }
}