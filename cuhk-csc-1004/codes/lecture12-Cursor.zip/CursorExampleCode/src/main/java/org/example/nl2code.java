package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class NumberFileReader {
    public static void main(String[] args) {
        // Path to the file
        String fileName = "number.txt";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            // Read file line by line
            while ((line = reader.readLine()) != null) {
                try {
                    // Parse and print each number
                    int number = Integer.parseInt(line.trim());
                    System.out.println("Number: " + number);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid number format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}

// please ensure the files is stored in the "src/main/resources" folder.
// please also calculate the summation of read numbers and store the results in a .csv file named "sum.csv"
