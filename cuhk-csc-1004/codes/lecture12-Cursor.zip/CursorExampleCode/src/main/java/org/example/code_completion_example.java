public class NumberPrinter {
    public static void main(String[] args) {
        Thread thread = ...
        thread.start();
    }
}

