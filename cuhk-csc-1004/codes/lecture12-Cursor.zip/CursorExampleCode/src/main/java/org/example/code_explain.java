import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public class ChatServer {

    private static final int PORT = 5000;
    private static final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        System.out.println("🚀 Chat server running on port " + PORT);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(clientSocket);
                clients.add(handler);
                new Thread(handler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Broadcasts message to all clients
    static void broadcast(String message, String sender) {
        for (ClientHandler client : clients) {
            client.sendMessage(sender + ": " + message);
        }
        insertMessageToDB(sender, message);
    }

    // Store message in MySQL
    static void insertMessageToDB(String sender, String message) {
        String url = "jdbc:mysql://localhost:3306/chatroom";
        String user = "root"; // change as needed
        String password = ""; // change as needed

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO messages (sender, message) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, sender);
            stmt.setString(2, message);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("❌ DB Error: " + e.getMessage());
        }
    }

    // Inner class to handle each client connection
    static class ClientHandler implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private String name;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        void sendMessage(String msg) {
            out.println(msg);
        }

        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            ) {
                out = new PrintWriter(socket.getOutputStream(), true);
                out.println("Enter your name:");
                name = in.readLine();

                String input;
                while ((input = in.readLine()) != null) {
                    System.out.println(name + ": " + input);
                    ChatServer.broadcast(input, name);
                }

            } catch (IOException e) {
                System.out.println("❌ Connection lost with " + name);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                clients.remove(this);
            }
        }
    }
}