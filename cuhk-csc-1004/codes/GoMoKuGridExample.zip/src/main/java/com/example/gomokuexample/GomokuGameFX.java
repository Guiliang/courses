package com.example.gomokuexample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class GomokuGameFX extends Application {
    private static final int CELL_SIZE = 40;
    private static final int BOARD_SIZE = 15;
    private static final int BOARD_LENGTH = CELL_SIZE * BOARD_SIZE;
    private GomokuGame game;

    private static StackPane createBlock() {
        StackPane block = new StackPane();
        block.setPrefSize(CELL_SIZE, CELL_SIZE);
        block.setStyle("-fx-border-color: black");
        return block;
    }

    @Override
    public void start(Stage primaryStage) {
        game = new GomokuGame(BOARD_SIZE);
        StackPane root = new StackPane();
        // init the grid pane for the key board
        GridPane grid = new GridPane();
        // init the blocks for the grid
        StackPane[][] blocks = new StackPane[BOARD_SIZE][BOARD_SIZE];
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                StackPane block = createBlock();
                blocks[i][j] = block;
                grid.add(block, j, i);
            }
        }
        root.getChildren().add(grid);

        grid.setOnMouseClicked(e -> {
            int x = (int) (e.getX() / CELL_SIZE);
            int y = (int) (e.getY() / CELL_SIZE);
            int currentPlayer = game.getCurrentPlayer();
            if (game.move(x, y)) {
                // draw the stone
                StackPane block = blocks[y][x];
                double circSize = 0.4 * CELL_SIZE;      // 0.8 / 2 for radius
                Circle circle = new Circle(circSize);   // may use `arc` for different arc color
                Color color = currentPlayer == 1 ? Color.BLACK : Color.WHITE;
                circle.setFill(color);
                circle.setStroke(Color.BLACK);          // border color
                block.getChildren().add(circle);
                if (game.isGameOver()) {
                    if (game.getWinner() == 0) {
                        System.out.println("Game over! It's a draw!");
                    } else {
                        System.out.println("Game over! The winner is player " + game.getWinner() + "!");
                    }
                }
            } else {
                System.out.println("Invalid move!");
            }
        });
        Scene scene = new Scene(root, BOARD_LENGTH, BOARD_LENGTH);
        primaryStage.setTitle("Gomoku Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    
    public static void main(String[] args) {
        launch(args);
    }
}